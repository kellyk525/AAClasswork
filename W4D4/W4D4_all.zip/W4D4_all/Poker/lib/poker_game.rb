class Poker_Game
  def initialize
    
  end
end

# 1 players
# populate each player with 5 card (random from 52 cards)
# look at card
# bet (accepts num)
# each player can discard cards
# look at new hand
# bet again
# end of game